<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Housecategories extends Model
{
}
