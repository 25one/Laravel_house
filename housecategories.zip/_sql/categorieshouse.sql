-- phpMyAdmin SQL Dump
-- version 4.7.8
-- https://www.phpmyadmin.net/
--
-- Хост: ag248566.mysql.ukraine.com.ua
-- Время создания: Май 25 2018 г., 12:42
-- Версия сервера: 5.7.16-10-log
-- Версия PHP: 7.0.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `ag248566_laravel`
--

-- --------------------------------------------------------

--
-- Структура таблицы `categorieshouse`
--

CREATE TABLE `categorieshouse` (
  `id` int(12) NOT NULL,
  `category` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `categorieshouse`
--

INSERT INTO `categorieshouse` (`id`, `category`) VALUES
(1, 'Bedrooms'),
(2, 'Bathrooms'),
(3, 'Storeys'),
(4, 'Garages');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `categorieshouse`
--
ALTER TABLE `categorieshouse`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `categorieshouse`
--
ALTER TABLE `categorieshouse`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
