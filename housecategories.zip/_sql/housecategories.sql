-- phpMyAdmin SQL Dump
-- version 4.7.8
-- https://www.phpmyadmin.net/
--
-- Хост: ag248566.mysql.ukraine.com.ua
-- Время создания: Май 25 2018 г., 12:28
-- Версия сервера: 5.7.16-10-log
-- Версия PHP: 7.0.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `ag248566_laravel`
--

-- --------------------------------------------------------

--
-- Структура таблицы `housecategories`
--

CREATE TABLE `housecategories` (
  `id` int(12) NOT NULL,
  `id_house` int(12) NOT NULL,
  `id_category` int(12) NOT NULL,
  `count` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `housecategories`
--

INSERT INTO `housecategories` (`id`, `id_house`, `id_category`, `count`) VALUES
(1, 1, 1, 4),
(2, 2, 1, 4),
(3, 3, 1, 4),
(4, 4, 1, 4),
(5, 5, 1, 4),
(6, 6, 1, 5),
(7, 7, 1, 3),
(8, 8, 1, 3),
(9, 9, 1, 4),
(10, 1, 2, 2),
(11, 2, 2, 2),
(12, 3, 2, 3),
(13, 4, 2, 2),
(14, 5, 2, 3),
(15, 6, 2, 2),
(16, 7, 2, 2),
(17, 8, 2, 2),
(18, 9, 2, 3),
(19, 1, 3, 2),
(20, 2, 3, 1),
(21, 3, 3, 2),
(22, 4, 3, 2),
(23, 5, 3, 2),
(24, 6, 3, 1),
(25, 7, 3, 2),
(26, 8, 3, 1),
(27, 9, 3, 2),
(28, 1, 4, 2),
(29, 2, 4, 2),
(30, 3, 4, 3),
(31, 4, 4, 2),
(32, 5, 4, 2),
(33, 6, 4, 2),
(34, 7, 4, 2),
(35, 8, 4, 1),
(36, 9, 4, 2);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `housecategories`
--
ALTER TABLE `housecategories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_house` (`id_house`,`id_category`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `housecategories`
--
ALTER TABLE `housecategories`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
